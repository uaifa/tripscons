<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Meal extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['name', 'status', 'active'];

    /**
     * @return mixed
     * @Author Khuram Qadeer.
     */
    public static function getAll()
    {
        return self::where('active', 1)->orderBy('id','ASC')->get();
    }

    /**
     * @Description  Get By name $meal
     *
     * @param $name
     * @return mixed
     *
     * @Author Khuram Qadeer.
     */
    public static function getByName($name)
    {
        return self::where('name', $name)->first();
    }

    /**
     * @Description Get meals By user id and ref id and ref type;
     *
     * @param $userId
     * @param $refId
     * @param $refType
     * @return array
     *
     * @Author Khuram Qadeer.
     */
    public static function getMealsByRef($userId, $refId, $refType)
    {
        $meals = [];
        $mealsLinks = MealLink::where([['user_id', $userId], ['ref_id', $refId], ['ref_type', $refType]])->get();
        if ($mealsLinks) {
            foreach ($mealsLinks as $mealsLink) {
                $meal = Meal::find($mealsLink->meal_id);
                if ($meal) {
                    array_push($meals, $meal);
                }
            }
        }
        return $meals;
    }
    public function images(){
        return $this->hasMany(Image::class,'module_id', 'id')->where('module','meal');
        //->select(['name','type','module'])  check why not working soon
        }
        public function singleImage(){
           return $this->hasOne(Image::class,'module_id', 'id')->where('module','meal');      
        }
       public function meal_ingrediant(){
       return $this->hasMany(MealIngridiant::class,'meal_id', 'id');
      
    }
    
}
