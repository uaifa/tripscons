<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{

    protected $fillable = ['conversion_id', 'sender_id', 'receiver_id', 'message', 'files', 'status', 'active'];

    /**
     * @Description Get All Messages by Conversion Id
     *
     * @param $conversionId
     * @return mixed
     *
     * @Author Khuram Qadeer.
     */
    public static function getByConversionId($conversionId)
    {
        return self::where('conversion_id', $conversionId)->orderBy('created_at', 'asc')->get();
    }


}
