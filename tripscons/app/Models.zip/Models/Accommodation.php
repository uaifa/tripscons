<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;

class Accommodation extends Model
{
    use SoftDeletes;
    /**
     * @var array
     */
    protected $fillable = [
        
        'title',	
        'no_of_rooms'	,
        'no_of_people',	
        'description',	
        'lat',	
        'lng',	
        'per_night'	,
        'type_id',	
        'type_name',	
        'sub_type_id',	
        'sub_type_name',	
        'min_stay',	
        'max_stay',	
        'dicount',	
        'phone'	,
        'taxes_fees',	
        'location',	
        'stars'	,
        'rating',	
        'status'
    ];
   
     public function images(){
     return $this->hasMany(Image::class,'module_id', 'id')->where('module','accommodation');
     //->select(['name','type','module'])  check why not working soon
     }
     public function singleImage(){
        return $this->hasOne(Image::class,'module_id', 'id')->where('module','accommodation') ;      
     }
    public function facility(){
    return $this->hasMany(FacilityAccommodation::class,'accommodation_id', 'id');
   
 }
 

}
