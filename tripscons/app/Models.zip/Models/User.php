<?php

namespace App\Models;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;

class User extends Authenticatable
{
    use Notifiable, HasApiTokens;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        
        'email', 'status', 'postal_code', 'address', 'country_code', 'email_verified_at', 'provider_id', 'provider', 'type', 'pin_code', 'gender', 'phone', 'phone_verified_at', 'is_phone_verified', 'state_id', 'city_id', 'country', 'state', 'city', 'country_short_name', 'state_short_name', 'city_short_name', 'longitude', 'latitude', 'password', 'token', 'about', 'tag_line', 'name', 'role_status', 'role_id', 'username', 'hourly_rate', 'is_host', 'currency_id', 'verified', 'date_of_birth', 'per_day_rate', 'is_mate', 'host_out_of_city', 'api_token', 'phone_code', 'is_profile_complete', 'role_profile_id'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public static function getUserToken($userId)
    {
        return self::find($userId)['api_token'];
    }
    public function activity(){
        return $this->hasMany(UserActivity::class,'user_id', 'id');      
     }
     public function trips(){
        return $this->hasMany(Trip::class,'user_id', 'id')->with('singleImage');      
     }
}
