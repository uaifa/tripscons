<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserMeal extends Model
{
    use SoftDeletes;

    /**
     * @var array
     */
    protected $fillable = ['user_id', 'meal_id', 'title', 'type',
        'description', 'images', 'rules', 'status', 'active',
        'price','ingredients','video_url','persons'
    ];

    /**
     * @Description Get All Meals those are user provided by user id
     *
     * @param $userId
     * @return mixed
     *
     * @Author Khuram Qadeer.
     */
    public static function getByUserId($userId)
    {
        $res = [];
        $userMeals = self::where([['user_id', $userId], ['active', 1]])->orderBy('id', 'DESC')->get();
        if ($userMeals) {
            foreach ($userMeals as $userMeal) {
                $meal = Meal::find($userMeal->meal_id);
                if ($meal) {
                    $userMeal['meal_name'] = $meal;
                    array_push($res, $userMeal);
                }
            }
        }
        return $res;
    }


    /**
     * @Description Get By id Meals
     * @param $id
     * @return array
     * @Author Khuram Qadeer.
     */
    public static function getById($id)
    {
        $res = [];
        $userMeal = self::find($id);
        if ($userMeal) {
            $meal = Meal::find($userMeal->meal_id);
            if ($meal) {
                $userMeal['meal_name'] = $meal;
                array_push($res, $userMeal);
            }
        }
        return $res[0];
    }
}
