<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['user_id', 'provider_id', 'description', 'type', 'ref_id', 'status', 'active'];

    /**
     * @Description Get Orders and orders items by reference id and reference type
     * @param $refId
     * @param $refType
     * @return array
     * @Author Khuram Qadeer.
     */
    public static function getOrderByRefIdAndRefType($refId, $refType)
    {
        $res = [];
        $orders = self::where([['ref_id', $refId], ['type', $refType]])->get();
        if ($orders) {
            foreach ($orders as $order) {
                $data = [];
                $data['order'] = $order;
                $data['order_items'] = OrderItem::getByOrderId($order->id);
                array_push($res, $data);
            }
        }
        return $res;
    }
}
