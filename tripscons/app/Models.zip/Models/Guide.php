<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Guide extends Model
{
    use HasFactory;
         public function images(){
        return $this->hasMany(Image::class,'module_id', 'id')->where('module','guide');
        
        }
        public function singleImage(){
           return $this->hasOne(Image::class,'module_id', 'id')->where('module','guide');    
        }
        public function guide_user(){
            return $this->hasOne(User::class,'id','user_id');
        }

        public function destination(){
            return $this->hasMany(GuideDestination::class,'guide_id', 'id');
            }
            public function activities(){
                return $this->hasMany(GuideActivity::class,'guide_id', 'id');
                }
    
}
