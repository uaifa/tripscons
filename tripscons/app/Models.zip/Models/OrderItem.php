<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['user_id', 'provider_id', 'order_id'
        , 'ref_id', 'ref_type', 'price', 'quantity', 'total', 'status', 'active',
        'date_from', 'date_to', 'time', 'day_or_hourly', 'in_city', 'pick_up_location', 'detail_in_json',
    ];

    /**
     * @Description Get All order items by order id
     * @param $orderId
     * @return mixed
     *
     * @Author Khuram Qadeer.
     */
    public static function getByOrderId($orderId)
    {
        return self::whereOrder_id($orderId)->get();
    }
}
