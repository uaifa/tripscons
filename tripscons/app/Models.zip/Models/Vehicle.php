<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vehicle extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['name'];

    /**
     * @Description Get All
     * @return Vehicle[]|\Illuminate\Database\Eloquent\Collection
     * @Author Khuram Qadeer.
     */
    public static function getAll()
    {
        return self::all();
    }
}
