<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;

class UserAccommodation extends Model
{
    use SoftDeletes;
    /**
     * @var array
     */
    protected $fillable = [
        'user_id', 'title', 'type', 'no_of_people', 'description', 'images', 'status',
        'active', 'rules', 'check_in', 'check_out', 'per_day', 'per_night', 'latitude', 'longitude',
        'type_id', 'type_name', 'sub_type_id', 'sub_type_name', 'property_type', 'smart_pricing',
        'min_price', 'max_price', 'notice_before_in_days', 'can_stay_max', 'can_stay_min', 'private_bath',
        'personal_setup', 'listing_as_company', 'discount_week_1', 'discount_week_2', 'discount_week_3',
        'discount_week_4', 'use_profile_number', 'phone', 'guest_can_contact', 'clean_fee',
        'service_fee', 'taxes_fees', 'limit_people', 'extra_price', 'country', 'state', 'city',
        'enquiry_allow', 'enquiry_response', 'location', 'shared_bath', 'flexibility_hours',
        'occupancy_limit_percentage', 'occupancy_rate_percentage', 'advance_pay',
        'video_url', 'pre_arrival_notice', 'notice_before_in_hours', 'apartment_type', 'flats',
        'stars', 'rooms', 'important_points','belongings','phone_code'
    ];

    /**
     * @Description Get All Accommodation those are user provided by user id
     * @param $userId
     * @return mixed
     * @Author Khuram Qadeer.
     */
    public static function getByUserId($userId)
    {
        $res = [];
        $accommodations = self::where([['user_id', $userId], ['active', 1]])->orderBy('id', 'DESC')->get();
        if ($accommodations) {
            foreach ($accommodations as $accommodation) {
                $data = [];
                $data = $accommodation;
                $data['about_accommodation_links'] = \App\Models\AboutAccommodationLink::getByAccommodationId($accommodation->id);
                $data['beds_types_links'] = \App\Models\BedsTypesLink::getByAccommodationId($accommodation->id);
                $data['safety_amenity_links'] = \App\Models\SafetyAmenityLink::getByAccommodationId($accommodation->id);
                $data['facilities'] = Facility::getFacilitiesByRef($userId, $accommodation->id, 'host:accommodation');
                $data['share_accommodation_links'] = ShareAccommodationLink::getByAccommodationId($userId, $accommodation->id);
                $data['facilities'] = Facility::getFacilitiesByRef($userId, $accommodation->id, 'host:accommodation');
                $data['near_by_places'] = NearByPlacesLink::getByRefId($userId, $accommodation->id, 'host:accommodation');
                array_push($res, $data);
            }
        }
        return $res;
    }

    /**
     * @Description Get Accommodation data by accommodation id
     * @param $userId
     * @param $accommodationId
     * @return array
     * @Author Khuram Qadeer.
     */
    public static function getByAccommodationId($accommodationId,$userId=null)
    {
        $res = [];
        $accommodation = self::find($accommodationId);
        if ($accommodation) {
            if ($userId == null){
                $userId = $accommodation->user_id;
            }
            $res = $accommodation;
            $res['about_accommodation_links'] = \App\Models\AboutAccommodationLink::getByAccommodationId($accommodationId);
            $res['beds_types_links'] = \App\Models\BedsTypesLink::getByAccommodationId($accommodationId);
            $res['safety_amenity_links'] = \App\Models\SafetyAmenityLink::getByAccommodationId($accommodationId);
            $res['facilities'] = Facility::getFacilitiesByRef($userId, $accommodationId, 'host:accommodation');
            $res['share_accommodation_links'] = ShareAccommodationLink::getByAccommodationId($userId, $accommodationId);
            $data['facilities'] = Facility::getFacilitiesByRef($userId, $accommodation->id, 'host:accommodation');
            $res['near_by_places'] = NearByPlacesLink::getByRefId($userId, $accommodationId, 'host:accommodation');
        }
        return $res;
    }

    /**
     * @Description get accommodation by user and location
     * @param $userId
     * @param $city
     * @return array
     * @Author Khuram Qadeer.
     */
    public static function locationExistInAccommodation($userId, $city)
    {
        $res = [];
        $accommodations = self::getByUserId($userId);
        //echo $userId;exit;
        if ($accommodations) {
            foreach ($accommodations as $accommodation) { //echo $accommodation->location;exit;
                //if (strcasecmp($accommodation->location, $city) == 0) { echo 123;exit;
                if (strpos($accommodation->location, $city) !== false) {    
                    array_push($res, $accommodation);
                }
            }
        }
        //dd($res);
        return $res;
    }

}
