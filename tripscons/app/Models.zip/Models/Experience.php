<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Experience extends Model
{
    use HasFactory;
    public function images(){
        return $this->hasMany(Image::class,'module_id', 'id')->where('module','experience');
        //->select(['name','type','module'])  check why not working soon
        }
        public function singleImage(){
           return $this->hasOne(Image::class,'module_id', 'id')->where('module','experience'); 
        }
       public function experience_facility_excluded(){
       return $this->hasMany(ExperienceFacility::class,'experience_id', 'id')->where('is_included','0');
}
public function experience_facility_included(){
    return $this->hasMany(ExperienceFacility::class,'experience_id', 'id')->where('is_included','1');
    //1 means included 
}
}
