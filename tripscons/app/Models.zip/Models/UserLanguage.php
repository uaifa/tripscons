<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserLanguage extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['language_id', 'user_id', 'status', 'active', 'ref_id', 'ref_type'];

    /**
     * @Description Get User Languages
     *
     * @param $userId
     * @return mixed
     *
     * @Author Khuram Qadeer.
     */
    public static function getUserLanguages($userId)
    {
        return self::where([['user_id', $userId], ['ref_type', 'users']])->get();
    }

    /**
     * @Description Delete Record by user id , reference id and reference type
     * @param $userId
     * @param $refId
     * @param $refType
     * @return mixed
     * @Author Khuram Qadeer.
     */
    public static function deleteByUserIdRefIdRefType($userId, $refId, $refType)
    {
        return self::where([['user_id', $userId], ['ref_id', $refId], ['ref_type', $refType]])->delete();
    }

    /**
     * @Description Get All Languages by user id, reference id and reference type
     * @param $userId
     * @param $refId
     * @param $refType
     * @return array
     * @Author Khuram Qadeer.
     */
    public static function getByUserIdRefIdRefType($userId, $refId, $refType)
    {
        $res = [];
        $records = self::where([['user_id', $userId], ['ref_id', $refId], ['ref_type', $refType]])->get();
        if ($records) {
            foreach ($records as $record) {
                $data = [];
                $language = Language::find($record->language_id);
                if ($language) {
                    $data['data'] = $record;
                    $data['language'] = $language;
                    array_push($res, $data);
                }
            }
        }
        return $res;
    }

    /**
     * @Description Get By Reference id and reference type
     * @param $refId
     * @param $refType
     * @return array
     * @Author Khuram Qadeer.
     */
    public static function getByRefIdAndType($refId, $refType)
    {
        $res = [];
        $records = self::where([['ref_id', $refId], ['ref_type', $refType]])->get();
        if ($records) {
            foreach ($records as $record) {
                $data = [];
                $language = Language::find($record->language_id);
                if ($language) {
                    $data['data'] = $record;
                    $data['language'] = $language;
                    array_push($res, $data);
                }
            }
        }
        return $res;
    }

}
