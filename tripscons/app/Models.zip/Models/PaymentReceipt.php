<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentReceipt extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['user_id', 'order_id', 'card_id', 'customer_id', 'transaction_id',
        'amount', 'percentage_amount', 'status', 'active', 'advance_amount', 'advance_status',
        'errors'];

    /**
     * @Description Get Payment Record by order id
     * @param $orderId
     * @return mixed
     * @Author Khuram Qadeer.
     */
    public static function getByOrderId($orderId)
    {
        return self::whereOrder_id($orderId)->first();
    }


}
